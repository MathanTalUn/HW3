package ast;
public abstract class AstExpVar extends AstExp {
    public AstExpVar(int lineNumber) { super(lineNumber); }
}