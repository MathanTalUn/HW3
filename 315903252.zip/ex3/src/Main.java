import java.io.*;
import java.io.PrintWriter;
import java_cup.runtime.Symbol;
import ast.*;

public class Main
{
	static public void main(String argv[])
	{
		Lexer l;
		Parser p;
		Symbol s;
		AstDecList ast;
		FileReader fileReader;
		PrintWriter fileWriter = null;
		String inputFileName = argv[0];
		String outputFileName = argv[1];
		
		try
		{
			/********************************/
			/* [1] Initialize a file reader */
			/********************************/
			fileReader = new FileReader(inputFileName);

			/********************************/
			/* [2] Initialize a file writer */
			/********************************/
			fileWriter = new PrintWriter(outputFileName);
			
			/******************************/
			/* [3] Initialize a new lexer */
			/******************************/
			l = new Lexer(fileReader);
			
			/*******************************/
			/* [4] Initialize a new parser */
			/*******************************/
			p = new Parser(l);

			/***********************************/
			/* [5] 3 ... 2 ... 1 ... Parse !!! */
			/***********************************/
			ast = (AstDecList) p.parse().value;
			
			/*************************/
			/* [6] Print the AST ... */
			/*************************/
			ast.printMe();

			/**************************/
			/* [7] Semant the AST ... */
			/**************************/
			ast.semantMe();
			
			/**************************/
			/* [8] Write "OK" result  */
			/**************************/
			fileWriter.print("OK");
			
			/*************************/
			/* [9] Close output file */
			/*************************/
			fileWriter.close();

			/**************************************/
			/* [10] Finalize AST GRAPHIZ DOT file */
			/**************************************/
			AstGraphviz.getInstance().finalizeFile();
    	}
		catch (Exception e)
		{
            try {
                // If fileWriter wasn't initialized try to open it now
                if (fileWriter == null) {
                    fileWriter = new PrintWriter(outputFileName);
                }
                
                // If an error occurred (Syntax or Semantic), write the error message to the file
                if (e.getMessage() != null && e.getMessage().startsWith("ERROR")) {
                    fileWriter.print(e.getMessage());
                } else {
                    // For unexpected exceptions, print trace to console and generic ERROR to file
                    e.printStackTrace();
                    fileWriter.print("ERROR");
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            } finally {
                // Ensure file is closed
                if (fileWriter != null) {
                    fileWriter.close();
                }
            }
		}
	}
}