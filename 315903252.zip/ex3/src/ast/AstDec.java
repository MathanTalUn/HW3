package ast;
public abstract class AstDec extends AstNode {
    public AstDec(int lineNumber) { super(lineNumber); }
}