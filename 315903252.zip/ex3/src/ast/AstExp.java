package ast;
public abstract class AstExp extends AstNode {
    public AstExp(int lineNumber) { super(lineNumber); }
}