package ast;
public abstract class AstStmt extends AstNode {
    public AstStmt(int lineNumber) { super(lineNumber); }
}